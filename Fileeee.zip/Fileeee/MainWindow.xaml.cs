﻿using Microsoft.Win32;
using System.IO;
using System.Text;
using System.Text.Unicode;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Fileeee
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DispatcherTimer _hoverTimer;
        public MainWindow()
        {
            InitializeComponent();
            _hoverTimer = new DispatcherTimer();
            _hoverTimer.Interval = TimeSpan.FromSeconds(1);  // Устанавливаем время для MouseHover
            _hoverTimer.Tick += HoverTimer_Tick;
        }
        private void BtnCreateFile_Click(object sender, RoutedEventArgs e)
        {// sohranenie spiska v file
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Текстовые файлы (*.txt)|*.txt|Скриты (*.sql)|*.sql|Документы (*.docx)|*.docx";
            if (sfd.ShowDialog() == true)
            { //perebiraem vse danneie v spiske
                string FilePath = sfd.FileName;
                StreamWriter swriter = new StreamWriter(FilePath);
                foreach (string item in LstDataFile1.Items)
                {
                    swriter.WriteLine(item);
                }
                swriter.Close();
                MessageBox.Show($"Данные сохранены в файл {FilePath}");
            }
            else
            {
                MessageBox.Show("Пользователь отказался от окна сохранения");
            }
        }

        private void BtnOpenFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Текстовые файлы (*.txt)|*.txt|Скриты (*.sql)|*.sql|Документы (*.docx)|*.docx";
            if (ofd.ShowDialog() == true)
            {
                string FilePath = ofd.FileName;
                StreamReader sreader = new StreamReader(FilePath, Encoding.UTF8);

                while (!sreader.EndOfStream) // пока не конец потока

                {
                    string line = sreader.ReadLine();
                    LstDataFile2.Items.Add(line);
                }
                sreader.Close();
            }
        }
        private void BtnAddItem_Click(object sender, RoutedEventArgs e)
        {
            string line = TxtAdd.Text;

            // Если строка пуста, выводим сообщение об ошибке
            if (string.IsNullOrWhiteSpace(line))
            {
                MessageBox.Show("Введите текст для добавления.");
                return;
            }
            // Проверяем, была ли выбрана строка для редактирования
            if (LstDataFile1.SelectedItem != null)
            {
                // Заменяем старую строку на новую в списке
                int selectedIndex = LstDataFile1.SelectedIndex;
                LstDataFile1.Items[selectedIndex] = line;
                MessageBox.Show("Строка успешно обновлена.");
            }
            else
            {
                LstDataFile1.Items.Add(line);
            }

            // Очищаем текстовое поле
            TxtAdd.Clear();
        }
        private void BtnRemoveItem_Click(object sender, RoutedEventArgs e)
        {
            if (LstDataFile1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Выделите текст для удаления списка.", "Предупреждение");
            }
            else
            {
                while (LstDataFile1.SelectedItems.Count > 0)// yдаляем все выбранные элементы из списка
                {
                    LstDataFile1.Items.Remove(LstDataFile1.SelectedItems[0]);
                }
            }
        }
        private void BtnEditItem_Click(object sender, RoutedEventArgs e)
        {
            if (LstDataFile1.SelectedItem == null)// проверяем, что выбрана хотя бы одна строка
            {
                MessageBox.Show("Выберите элемент для редактирования.");
                return;
            }
            string selectedItem = LstDataFile1.SelectedItem.ToString();
            TxtAdd.Text = selectedItem;
        }
        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            LstDataFile1.Items.Clear();
            LstDataFile2.Items.Clear();
        }
        private void BtnExze_MouseEnter(object sender, MouseEventArgs e)
        {
            _hoverTimer.Start();
        }

        private void HoverTimer_Tick(object sender, EventArgs e)
        {
            MessageBox.Show("Нажмите для удаления первой буквы");
            _hoverTimer.Stop();
        }
        private void BtnExze_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, что в списке есть выделенные элементы
            if (LstDataFile1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Выделите элементы для выполнения задания.");
                return;
            }

            // Применяем функцию удаления первой буквы для каждого выбранного элемента
            for (int i = 0; i < LstDataFile1.SelectedItems.Count; i++)
            {
                string selectedItem = LstDataFile1.SelectedItems[i].ToString();
                // Разбиваем строку на слова
                string[] words = selectedItem.Split(' ');
                for (int j = 0; j < words.Length; j++)
                {
                    if (words[j].Length > 0)
                    {
                        words[j] = words[j].Substring(1); // Удаляем первую букву
                    }
                }
                string modifiedItem = string.Join(" ", words);
                int index = LstDataFile1.Items.IndexOf(LstDataFile1.SelectedItems[i]);
                LstDataFile1.Items[index] = modifiedItem;
            }
        }
        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Escape)
            {
                this.Close();
            }
        }

        private void BtnArray_Click(object sender, RoutedEventArgs e)
        {
            WindowArray windowArray = new WindowArray();
            windowArray.Show();

        }
    }
}
  

