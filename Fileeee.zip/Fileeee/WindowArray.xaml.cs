﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Fileeee
{
    public partial class WindowArray : Window
    {
        private double[] arrayNumber = new double[25]; // Массив с числами
        private int N = 25; // Количество элементов в массиве
        double[] D = new double[25];  // Массив D
        double[] E = new double[25];  // Массив E
 

        public WindowArray()
        {
            InitializeComponent();
            FillListBoxWithRandomNumbers();
        }

        // Метод для заполнения ListBox случайными числами
        private void FillListBoxWithRandomNumbers()
        {
            Random rand = new Random();
            List<double> randomNumbers = new List<double>();

            // Заполнение массивов D и E случайными числами
            for (int i = 0; i < D.Length; i++)
            {
                D[i] = rand.Next(1, 100);  // Случайные числа от 1 до 100 для D
                E[i] = rand.Next(-100, 100); // Случайные числа от -100 до 100 для E
                randomNumbers.Add(D[i]); // Добавляем значения D в список для отображения
            }

            // Отображаем массив D в ListBox
            LstDataFile1.ItemsSource = randomNumbers;
        }

        private void BtnExze_Click(object sender, RoutedEventArgs e)
        {
            List<double> validResults = new List<double>();

            // Вычисление f(i) для каждого индекса от 1 до 16
            for (int i = 0; i < D.Length; i++)
            {
                double sineValue = Math.Sin(i);  // Синус от индекса (можно заменить на что-то другое по необходимости)
                double f = (2 * D[i] + sineValue) / D[i];

                // Проверяем условие: 1 < f(i) < 3
                if (f > 1 && f < 3)
                {
                    validResults.Add(f);  // Добавляем только те значения, которые удовлетворяют условию
                }
            }

            // Обновляем ListBox с подходящими значениями
            LstDataFile1.ItemsSource = validResults;
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            LstDataFile1.ItemsSource = null;
        }
    }
}